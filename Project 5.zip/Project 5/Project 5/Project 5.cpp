// Weather Station App.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Justin Acevedo

#include <iostream>
#include <string>
using namespace std;

void print(string weatherStation, string windDirection, double temp, int windSpeed, int hasInput)
{
    if (hasInput == false)
    {
        cout << "No input has been entered yet \n";
    }
    else
    {
        cout << weatherStation << endl;
        cout << endl;
        cout << temp << " degrees fahrenheit " << endl;
        cout << windSpeed << " MPH going " << windDirection << endl;
    }

}

bool exitCommand(int action)
{
    if (action == 3)
        return true;
    else
        return false;
}

void input(double& temp, int& windSpeed, string& windDirection, int& currentWheather, bool& hasInput)
{

    cout << "Enter the temperature in Fahrenheit : \n";
    cin >> temp;

    cout << "Enter the wind speed in MPH : \n";
    cin >> windSpeed;

    cout << "Enter the wind direction : " << endl;
    cin >> windDirection;
    

    hasInput = true;
    currentWheather++;

}


int main()
{
    string weatherStation, windDirection[5];
    double temp[5] = { 0,0,0,0,0 } ;
    int windSpeed[5] = { 0,0,0,0,0 }, action = 0, currentWeather = 0, printChoice = 0, prevWeather = 0;
    bool end = false, hasInput[5] = {false,false,false,false,false};

    cout << "Enter the name of a weather station : " << endl;
    getline(cin, weatherStation);
    cout << endl;

    while (end != true) {

        cout << "Enter 1 to input , 2 to print , and 3 to exit \n";
        cin >> action;

        if (currentWeather == 5)
            currentWeather = 1;

        if (action >= 1 && action <= 3)
        {
            if (action == 1)
            {
                input(temp[currentWeather], windSpeed[currentWeather], windDirection[currentWeather], currentWeather,hasInput[currentWeather]);
                
            }
            else
            {
                if (action == 2) {

                    cout << "Enter 1 for the current weather or 2 for weather history : \n";
                    cin >> printChoice;

                    if (printChoice == 1)
                    {
                        print(weatherStation, windDirection[currentWeather-1], temp[currentWeather-1], windSpeed[currentWeather-1], hasInput[currentWeather-1]);
                    }
                    else
                    {
                        for (int q = 0; q < 5; q++)
                        {
                            print(weatherStation, windDirection[q], temp[q], windSpeed[q], hasInput[q]);
                        }
                    }

                }
            }
            end = exitCommand(action);
        }
        else
        {
            cout << "Invalid input try again \n";
        }
    }
}
